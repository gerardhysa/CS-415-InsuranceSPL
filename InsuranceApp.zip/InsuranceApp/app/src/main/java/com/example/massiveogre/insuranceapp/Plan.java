package com.example.massiveogre.insuranceapp;

public class Plan {

    static String[] plans = new String[]{
            "Standard",
            "Silver",
            "Gold"
    };
}
